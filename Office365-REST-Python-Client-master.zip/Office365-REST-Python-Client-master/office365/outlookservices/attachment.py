from office365.runtime.client_object import ClientObject


class Attachment(ClientObject):
    """A file or item (contact, event or message) attached to an event or message."""
