from office365.runtime.client_object import ClientObject


class ContactFolder(ClientObject):
    """A folder that contains contacts."""
