from office365.outlookservices.item import Item


class Event(Item):
    """An event in a calendar."""
