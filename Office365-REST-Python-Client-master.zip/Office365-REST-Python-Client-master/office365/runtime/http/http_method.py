class HttpMethod:
    def __init__(self):
        pass

    Get = "GET"
    Post = "POST"
    Patch = "PATCH"
    Delete = "DELETE"
    Put = "PUT"
