class UserCredential(object):

    def __init__(self, user_name, password):
        self.userName = user_name
        self.password = password
