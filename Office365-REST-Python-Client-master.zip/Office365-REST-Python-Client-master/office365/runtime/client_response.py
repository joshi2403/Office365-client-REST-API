class ClientResponse(object):
    """Client response """


