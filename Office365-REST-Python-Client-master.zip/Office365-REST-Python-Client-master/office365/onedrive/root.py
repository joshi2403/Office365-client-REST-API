from office365.runtime.client_value_object import ClientValueObject


class Root(ClientValueObject):
    """Root container """
