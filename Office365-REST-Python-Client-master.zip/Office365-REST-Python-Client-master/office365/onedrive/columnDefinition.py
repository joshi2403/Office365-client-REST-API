from office365.onedrive.baseItem import BaseItem


class ColumnDefinition(BaseItem):
    """"""
