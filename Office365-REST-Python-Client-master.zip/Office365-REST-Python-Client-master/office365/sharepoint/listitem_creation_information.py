from office365.runtime.client_value_object import ClientValueObject


class ListItemCreationInformation(ClientValueObject):
    """Specifies the properties of the new list item."""
