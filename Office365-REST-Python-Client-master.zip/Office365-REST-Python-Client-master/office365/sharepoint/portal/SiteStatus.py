class SiteStatus:
    def __init__(self):
        pass

    NotFound = -0
    Provisioning = 1
    Ready = 2
    Error = 3
