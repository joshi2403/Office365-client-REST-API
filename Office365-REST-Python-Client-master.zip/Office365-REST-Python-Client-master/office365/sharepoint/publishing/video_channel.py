from office365.runtime.client_object import ClientObject


class VideoChannel(ClientObject):
    pass
