class MoveOperations:
    none = 0
    overwrite = 1
