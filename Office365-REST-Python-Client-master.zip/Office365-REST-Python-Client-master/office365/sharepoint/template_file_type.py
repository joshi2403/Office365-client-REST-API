class TemplateFileType:
    def __init__(self):
        pass

    StandardPage = 0
    WikiPage = 1
    FormPage = 2
